describe('Initial Server Test', function() {
  it('Should pass first', function() {
    expect(1).toBe(1);
  })
  it('Should fail second', function() {
    expect(2).toBe(1);
  })
})
