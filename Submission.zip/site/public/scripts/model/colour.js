"use strict";

/**
 * This file defines the colour a player can be, red or white.
 */

var Colour = {
  "red"   : "red",
  "white" : "white"
};
